#include <stdio.h>

int main(void) {
int a,b,sum;
  printf("enter the two numbers");
  scanf(%d%d,&a,&b);
  sum=a+b;
  printf("sum of two numbers is %d",sum);
  return 0;
}