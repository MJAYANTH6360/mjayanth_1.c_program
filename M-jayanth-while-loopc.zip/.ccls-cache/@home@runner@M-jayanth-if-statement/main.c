#include <stdio.h>

int main(void) {
int num=10;
  if(num>0){
    printf("the number is positive\n");
  }
  return 0;
  }