#include <stdio.h>

int main(void) {
  printf("entrer the value of principal,rateand time\n")
float principal,rate,time,si;
scanf("%f%f%f",&principal,&rate,&time);
si=(p*r*t)/100;
printf("the simple interest is %f",si);
'return0';
}