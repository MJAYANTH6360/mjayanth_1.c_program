#include<stdio.h>
int main()
if number > 0:
printf("positive");
else:
printf("negative");
'return 0';
}