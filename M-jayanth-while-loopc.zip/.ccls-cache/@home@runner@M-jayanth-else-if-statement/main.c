#include<stdio.h>
int main()
if number > 0:
printf()