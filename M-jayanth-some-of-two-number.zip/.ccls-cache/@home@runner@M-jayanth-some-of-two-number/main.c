#include <stdio.h>

int main(void) {
  int a,b,sum;
  printf("enter the two number");
  scanf("%d%d",&a,&b);
  sum=a+b;
  return 0;
}